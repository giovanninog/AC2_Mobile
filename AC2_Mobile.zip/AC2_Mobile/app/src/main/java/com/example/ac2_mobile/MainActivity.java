package com.example.ac2_mobile;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.ac2_mobile.models.Exercicio;
import com.example.ac2_mobile.ui.CadastroActivity;
import com.example.ac2_mobile.ui.TreinoActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public static ArrayList<Exercicio> listaExercicios = new ArrayList<>();
    ArrayAdapter<String> adapter;
    ListView listView;
    Button btnIniciar, btnCadastrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);
        btnCadastrar = findViewById(R.id.btnCadastrar);
        btnIniciar = findViewById(R.id.btnIniciar);

        btnCadastrar.setOnClickListener(v -> {
            Intent i = new Intent(this, CadastroActivity.class);
            startActivity(i);
        });

        btnIniciar.setOnClickListener(v -> {
            Intent i = new Intent(this, TreinoActivity.class);
            startActivity(i);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        ArrayList<String> nomes = new ArrayList<>();
        for (Exercicio e : listaExercicios) {
            nomes.add(e.getNome() + " - " + e.getDuracao() + "s");
        }
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, nomes);
        listView.setAdapter(adapter);
    }
}