package com.example.ac2_mobile.ui;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.ac2_mobile.services.NotificacaoService;
import com.example.ac2_mobile.models.Exercicio;
import com.example.ac2_mobile.MainActivity;
import com.example.ac2_mobile.R;

public class TreinoActivity extends AppCompatActivity {

    TextView tvNome, tvTempo;
    int index = 0;
    CountDownTimer timer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_treino);

        tvNome = findViewById(R.id.tvNome);
        tvTempo = findViewById(R.id.tvTempo);

        NotificacaoService.criarCanal(this);
        iniciarExercicio();
    }

    void iniciarExercicio() {
        if (index >= MainActivity.listaExercicios.size()) {
            NotificacaoService.enviar(this, "AC2_Mobile", "Treino concluído! Parabéns!", 999);
            finish();
            return;
        }

        Exercicio atual = MainActivity.listaExercicios.get(index);
        tvNome.setText(atual.getNome());
        NotificacaoService.enviar(this, "AC2_Mobile", "Iniciando: " + atual.getNome(), index + 1);

        timer = new CountDownTimer(atual.getDuracao() * 1000L, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                tvTempo.setText(String.valueOf(millisUntilFinished / 1000));
            }

            @Override
            public void onFinish() {
                index++;
                iniciarExercicio();
            }
        }.start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (timer != null) timer.cancel();
    }
}