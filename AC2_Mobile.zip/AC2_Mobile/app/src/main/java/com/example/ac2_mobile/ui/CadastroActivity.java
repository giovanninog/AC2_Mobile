package com.example.ac2_mobile.ui;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.example.ac2_mobile.models.Exercicio;
import com.example.ac2_mobile.MainActivity;
import com.example.ac2_mobile.R;

public class CadastroActivity extends AppCompatActivity {

    EditText etNome, etDuracao;
    Button btnSalvar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        etNome = findViewById(R.id.etNome);
        etDuracao = findViewById(R.id.etDuracao);
        btnSalvar = findViewById(R.id.btnSalvar);

        btnSalvar.setOnClickListener(v -> {
            String nome = etNome.getText().toString();
            int duracao = Integer.parseInt(etDuracao.getText().toString());
            MainActivity.listaExercicios.add(new Exercicio(nome, duracao));
            finish();
        });
    }
}